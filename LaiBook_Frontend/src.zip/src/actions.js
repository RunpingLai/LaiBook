const apiUrl = "http://localhost:3000"

export function logout() {
    fetch(`${apiUrl}/logout`, {
        credentials: 'include',
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        // body: JSON.stringify(BODY)
    }).then((response) => response.json())
        .then((response) => {
            if (response.result === "success") {
                console.log("logout successful")
            }
            else{
                console.log(response.result)
            }
        })

}

export async function getArticles() {
    var articles
    await fetch(`${apiUrl}/articles`, {
        credentials: 'include',
        method: 'GET'
    }).then((response) => response.json())
        .then((response) => {
            articles = response.articles
        })
    return articles
}