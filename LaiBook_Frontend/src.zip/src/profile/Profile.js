import React from "react";
import {users} from "../data"
import '../styleSheets.css'

import {Link} from "react-router-dom";

const imgSrc = "https://www.thesprucepets.com/thmb/UlqV5bn8o9orBDPqwC0pvn-PX4o=/941x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/GettyImages-145577979-d97e955b5d8043fd96747447451f78b7.jpg"


export default class Profile extends React.Component {
    constructor(props) {
        super(props);
        const userName = window.location.href.split("/")[4];
        let profile = users.filter(function (value, idx, arr) {
            return value.username === userName;
        })
        let starPasswords = "**************";
        // console.log(profile);
        if (profile.length === 0) {
            profile = hardCoded;
        }
        else {
            starPasswords = "";
            for (let i=0;i<profile[0].address.street.length;i++){
                starPasswords += "*";
            }
        }
        // console.log(profile);
        this.state = {myProfile:profile, userName:userName, starPassword: starPasswords, errors: []};
        this.updateInfo = this.updateInfo.bind(this);
        // this.updateInfo = this.updateInfo.bind(this);
    }


    updateInfo(e) {
        // e.preventDefault();
        const refs = this.refs;
        let newName = refs.newName.value;
        let newEmail = refs.newEmail.value;
        let newPhone = refs.newPhone.value;
        let newZip = refs.newZip.value;
        let newPassword = refs.newPassword.value;
        this.handleUpdateInfo(newName, newEmail, newPhone, newZip, newPassword);
    }



    handleUpdateInfo(newName, newEmail, newPhone, newZip, newPassword) {

        let oldProfile = this.state.myProfile;
        let errors = [];
        if (newName !== "") {
            var actnameformat = /^[A-Za-z0-9]*$/;
            var isValidActname;
            if (/[0-9]/.test(newName)) {
                isValidActname = false;
            }
            else {
                if (actnameformat.test(newName)) {
                    isValidActname = true;
                }
                else {
                    isValidActname = false;
                }
            }
            if (isValidActname === true) {
                oldProfile[0].name = newName;
            }
            else {
                errors.push("name format wrong");
            }
        }
        if (newEmail !== "") {
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            var isValidMail = mailformat.test(newEmail);
            if (isValidMail === true) {
                oldProfile[0].email = newEmail;
            }
            else {
                errors.push("email format wrong");
            }
        }
        if (newPhone !== "") {
            var phoneformat = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
            var isValidPhone = phoneformat.test(newPhone);
            if (isValidPhone === true) {
                oldProfile[0].phone = newPhone;
            }
            else {
                errors.push("phone format wrong");
            }
        }
        if (newZip !== "") {
            var zipcodeformat = /(^\d{5}$)|(^\d{5}-\d{4}$)/;
            var isValidZip = zipcodeformat.test(newZip);
            if (isValidZip === true) {
                oldProfile[0].address.zipcode = newZip;
            }
            else {
                errors.push("zipcode format wrong");
            }
        }
        if (newPassword !== "") {
            oldProfile[0].address.street = newPassword;
            var stars = "";
            for (let i=0; i<newPassword.length; i++){
                stars += "*";
            }
        }
        let newProfile = oldProfile;
        this.setState({myProfile: newProfile, starPassword: stars, errors:errors});
        // console.log(this.state.name);
        // console.log(e.target);
    }

    render() {
        return (
            <div>
                {this.state.myProfile.map( ({id, name, username, email, address, phone, website, company}) => (
                    <div key={id}>
                        <Link to={`/main/${this.state.userName}`}>Go to Main Page</Link>
                        <br />
                        <Link to="/">Log Out</Link><br />
                        <br />
                        <div>
                            <h2>Current Info</h2><br />
                            <img src={imgSrc} alt={"imgSrc didn't give me a pic!"} width={"40%"} height={"60%"}></img><br />
                            <span>Choose a photo from your device</span><br />
                            <input type={"file"}></input><br></br>
                            <span>{name}</span><br></br>
                            <span>{username}</span><br />
                            <span>{email}</span><br />
                            <span>{phone}</span><br />
                            <span>{this.state.starPassword}</span><br />
                            <span>{address.zipcode}</span>
                        </div>
                        <div>
                            <h2>Update Info</h2>
                            {this.state.errors.map((err) => (
                                <p class="notice" key={err}>Error: {err}</p>
                            ))}
                            <form onSubmit={this.updateInfo}>
                                <label>
                                    Name
                                    <input type={"text"} name={"newName"} ref={"newName"}/>
                                </label><br />
                                <label>
                                    Email
                                    <input type={"text"} ref={"newEmail"}/>
                                </label><br />
                                <label>
                                    Phone
                                    <input type={"text"} ref={"newPhone"}/>
                                </label><br />
                                <label>
                                    Zip
                                    <input type={"text"} ref={"newZip"}/>
                                </label><br />
                                <label>
                                    Password
                                    <input type={"password"} ref={"newPassword"}/>
                                </label><br />
                                <input type={"submit"} value={"Update Info"} />
                            </form>
                        </div>
                    </div>
                    )
                )}
            </div>
        )
    }
}


let hardCoded = [{
    "id": 100,
    "name": "Rice Univeristy",
    "username": "RiceU",
    "email": "RiceUniveristy@rice.edu",
    "address": {
        "street": "Shakespeare St",
        "suite": "Apt. 556",
        "city": "Houston",
        "zipcode": "77030",
        "geo": {
            "lat": "-37.3159",
            "lng": "81.1496"
        }
    },
    "phone": "123-123-1234",
    "website": "hildegard.org",
    "company": {
        "name": "Rice University",
        "catchPhrase": "Rice Univeristy",
        "bs": "harness real-time e-markets"
    }

}]