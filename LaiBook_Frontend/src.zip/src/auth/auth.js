import React from "react";
import {Navigate} from "react-router-dom";
import {users} from "../data";
import '../styleSheets.css'

// const isLocal = true
// export const apiUrl = isLocal ? "http://localhost:3000" : "herokuapp.com"
const apiUrl = "http://localhost:3000"

export class RegForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            AccountName: '',
            DisplayName: '',
            EmailAddress: '',
            PhoneNumber: '',
            DateofBirth: '',
            Zipcode: '',
            Password: '',
            PasswordCfm: '',
            errors: [],
            loginState: false
        };

        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
    }

    validate(form) {
        const errors = [];

        var actnameformat = /^[A-Za-z0-9]*$/;
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var phoneformat = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;;
        var zipcodeformat = /(^\d{5}$)|(^\d{5}-\d{4}$)/;

        var isValidActname;
        if (/[0-9]/.test(form.AccountName[0])) {
            isValidActname = false;
        }
        else {
            if (actnameformat.test(form.AccountName)) {
                isValidActname = true;
            }
            else {
                isValidActname = false;
            }
        }
        var isValidPhone = phoneformat.test(form.PhoneNumber);
        var isValidMail = mailformat.test(form.EmailAddress);
        var dob = new Date(form.DateofBirth);
        var today = new Date();
        var age = today.getFullYear() - dob.getFullYear();
        var m = today.getMonth() - dob.getMonth();
        var d = today.getDate() - dob.getDate();
        if ( m<0 || (m===0 && d < 0) ) {
            age--;
        }
        var isValidDob;
        if ( age < 18) {
            isValidDob = false;
        }
        else {
            isValidDob = true;
        }
        var isValidZip = zipcodeformat.test(form.Zipcode);
        var isPasswordMatch;
        if (form.Password === form.PasswordCfm) {
            isPasswordMatch = true;
        }
        else {
            isPasswordMatch = false;
        }

        if (!isValidActname) {
            errors.push("Account Name Error");
        }
        if (!isValidMail) {
            errors.push("Email Address Error");
        }
        if (!isValidPhone) {
            errors.push("Phone Number Error");
        }
        if( !isValidDob) {
            errors.push("Birthday Error");
        }
        if (!isValidZip) {
            errors.push("Zipcode Error");
        }
        if (!isPasswordMatch) {
            errors.push("Passwords don't match");
        }
        return errors
    }


    handleInputChange(event) {
        const target = event.target;
        const value = event.target.value;
        const name = target.name;
        this.setState({
            [name]: value
        });
    }

    handleSubmit(event) {
        event.preventDefault();
        const errors = this.validate(this.state);
        this.setState({ errors });
        if (errors.length > 0) {
            return;
        }

        var BODY = {
            username: this.state.AccountName,
            email: this.state.EmailAddress,
            dob: this.state.DateofBirth,
            zipcode: this.state.Zipcode,
            password: this.state.Password
        }
        fetch(`${apiUrl}/register`, {
            credentials: 'include',
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            // mode: 'no-cors',
            body: JSON.stringify(BODY)
        })
            .then((response) => response.json())
            .then((resp) => {
                if(resp.result === 'success') {
                    this.setState({loginState: true})
                }
                if(resp.result === 'failed') {
                    this.setState({errors: [resp.comment]})
                }
            })
            .catch((err) => {
                console.log(err.message)
            })
        // this.setState({loginState: true})
    }

    render() {

        if (this.state.loginState) {
            return <Navigate to={`/main/${this.state.AccountName}`} />
        }
        const errors = this.state.errors;
        return (
            <>
            <form onSubmit={this.handleSubmit}>
                {errors.map((err) => (
                    <p class="notice" key={err}>Error: {err}</p>
                ))}
                <label>
                    Account Name
                    <input name={"AccountName"} ref={"AccountName"} type={"text"} value={this.state.AccountName} onChange={evt => this.setState({AccountName: evt.target.value})} />
                </label>
                <br />
                <label>
                    Display Name
                    <input name={"DisplayName"} ref={"DisplayName"} type={"text"} value={this.state.DisplayName} onChange={evt => this.setState({DisplayName: evt.target.value})} />
                </label>
                <br />
                <label>
                    Email Address
                    <input name={"EmailAddress"} ref={"EmailAddress"} type={"text"} value={this.state.EmailAddress} onChange={evt => this.setState({EmailAddress: evt.target.value})} />
                </label>
                <br />
                <label>
                    Phone Number
                    <input name={"PhoneNumber"} ref={"PhoneNumber"} type={"text"} value={this.state.PhoneNumber} onChange={evt => this.setState({PhoneNumber: evt.target.value})}/>
                </label>
                <br />
                <label>
                    Date of Birth
                    <input name={"DateofBirth"} ref={"DateofBirth"} type={"date"} value={this.state.DateofBirth} onChange={evt => this.setState({DateofBirth: evt.target.value})} />
                </label>
                <br />
                <label>
                    Zipcode
                    <input name={"Zipcode"} ref={"Zipcode"} type={"number"} value={this.state.value} onChange={evt => this.setState({Zipcode: evt.target.value})} />
                </label>
                <br />
                <label>
                    Password
                    <input name={"Password"} ref={"Password"} type={"password"} value={this.state.value} onChange={evt => this.setState({Password: evt.target.value})} />
                </label>
                <br />
                <label>
                    Password Confirmation
                    <input name={"PasswordCfm"} ref={"PasswordCfm"} type={"password"} value={this.state.value} onChange={evt => this.setState({PasswordCfm: evt.target.value})} />
                </label>
                <br />
                <input type={"submit"} value={"Submit"}/>
            </form>

            </>
        )
    }
}

export class SignInForm extends React.Component{
    constructor(props) {
        super(props);
        this.state = {loginState: false,
            UserName: "",
            userId: "",
            errors: "",
            UsernameTypein: "",
            PasswordTypein: ""
        };

        // this.handleSubmit = this.handleSubmit.bind(this);

    }

    change = e => {
        this.setState({
            [e.target.name]: e.target.value
        })
        this.setState({loginState: false})
    }

    handleLogin = () => {
        var BODY = {
            username: this.state.UsernameTypein,
            password: this.state.PasswordTypein
        }
        fetch(`${apiUrl}/login`, {
            credentials: 'include',
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(BODY)
        })
            // .then((res) => console.log(res))
            .then((response) => response.json())
            .then((resp) => {
                if(resp.result === 'success') {
                    this.setState({
                        errors: "",
                        UserName: this.state.UsernameTypein,
                        loginState: true
                    })
                    console.log(`${resp.username} logged in successfully`)
                }
                else {
                    this.setState({errors: "No Such User or Wrong Password"})
                }
            })
            .catch((err) => {
                console.log(err.message)
            })
    }

    render() {
        if (this.state.loginState) {
            return <Navigate to={`/main/${this.state.UserName}`} />
        }
        else {

        }
        return (
            <>
                <p className="notice">{this.state.errors}</p>
                <label>
                    Username
                    <input name="UsernameTypein" ref="UserName" onChange={this.change} value={this.state.UsernameTypein} type={"text"} />
                </label>
                <br/>
                <label>
                    Password
                    <input name="PasswordTypein" ref="Password" onChange={this.change} value={this.state.PasswordTypein} type={"text"} />
                </label>
                <br/>
                <button className="signinbutton" name="Submit" onClick={this.handleLogin} value="Log in" />
            </>
        )
    }
}

export default function Auth() {
    return (
        <>
            <a href={"/auth/google"}>Sign in with google</a>
            <div className="regForm" name={"RegForm"}>
                <RegForm />
            </div>
            <div className="signForm" name={"SignInForm"}>
                <SignInForm />
            </div>
        </>
    )
}

// function matchJsonUsers(InputUsername, InputPassword) {
//     for (let i=0; i<users.length; i++) {
//         if (users[i].username === InputUsername && users[i].address.street === InputPassword) {
//             return true;
//         }
//     }
//     return false;
// }