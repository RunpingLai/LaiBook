import React from "react";
import {Link, Outlet} from "react-router-dom";
import {users, posts} from "../data";
import '../styleSheets.css'
import {logout, getArticles} from "../actions";
import uuid from 'react-uuid';
import axios from "axios"

const imgSrc = "https://www.thesprucepets.com/thmb/UlqV5bn8o9orBDPqwC0pvn-PX4o=/941x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/GettyImages-145577979-d97e955b5d8043fd96747447451f78b7.jpg"

const apiUrl = "http://localhost:3000"

export default class Main extends React.Component {
    constructor() {
        super();
        const userName = window.location.href.split("/")[4];

        this.handleStatusUpdate = this.handleStatusUpdate.bind(this);



        let userInfo = users.filter(function (value, index, arr) {
            return value.username === userName;
        })[0];
        var userStatus;
        if (userInfo) {
            // var userStatus;
            if (JSON.parse(window.localStorage.getItem(JSON.stringify(userName)))) {
                console.log(JSON.parse(window.localStorage.getItem(JSON.stringify(userName))));
                userStatus = JSON.parse(window.localStorage.getItem(JSON.stringify(userName))).userStatus_localStorage;
            }
            else {
                userStatus = userInfo.company.catchPhrase;
            }

            let userId = userInfo.id;
            this.state = {userId: userId, userName: userName, userStatus: userStatus, userStatusDraft: userStatus};
        } else {
            // var userStatus;
            if (JSON.parse(window.localStorage.getItem(JSON.stringify(userName)))) {
                userStatus = JSON.parse(window.localStorage.getItem(JSON.stringify(userName))).userStatus_localStorage;
            }
            else {
                userStatus = "I'm ok";
            }

            let userId = 100;
            this.state = {userId: userId, userName: userName, userStatus: userStatus, userStatusDraft: userStatus};
        }
    }

    handleStatusUpdate(e) {
        this.setState({userStatus: this.state.userStatusDraft});
        window.localStorage.setItem(JSON.stringify(this.state.userName), JSON.stringify({userStatus_localStorage: this.state.userStatusDraft}));
    }

    render() {
        return (
            <>

                <Link to={`/profile/${this.state.userName}`}>Go to Profile Page</Link>
                <br />
                <Link to="/" id={"logout"} onClick={logout}>Log Out</Link><br />
                <br />
                <h2>Personal Info</h2>
                <img className="mid" alt={"imgSrc didn't give me a pic!"} src={imgSrc} height={"20%"} width={"20%"} /><br />
                <span>{this.state.userName}</span><br />
                <span className="mid">{this.state.userStatus}</span>
                <textarea className="mid" defaultValue={this.state.userStatus} onChange={event => this.setState({userStatusDraft: event.target.value})}></textarea>
                {/*<button onClick={event => {this.setState({userStatus:this.state.userStatusDraft})}}>Update Your Status</button>*/}
                <button onClick={this.handleStatusUpdate}>Update Your Status</button>
                {/*<Follows userId={this.state.userId} />*/}
                <Outlet />
            </>
        )
    }

}

export class Posts extends React.Component {
    constructor(props) {
        super(props);
        const userName = window.location.href.split("/")[4];
        this.handleHideShowComment = this.handleHideShowComment.bind(this);
        this.handleAddPost = this.handleAddPost.bind(this);
        this.follow2post_func = this.follow2post_func.bind(this);
        // this.load = this.load.bind(this);
        this.state = {userName: userName};

        const userInfo = users.filter(
            function (user) {
                return user.username === userName;
            }
        );
        // const Barticles = getArticles()
        // console.log(Barticles.length)

        if (userInfo.length === 0) {
            this.state = {userId: 100, posts:[], backupposts:[]};
        }
        else {
            let userId = userInfo[0].id;
            let heAndhisFollowsIds = [userId, (userId + 1) % 10, (userId + 2) % 10, (userId + 3) % 10];
            this.state = {userId: userId, posts: getPostsByUserIds(heAndhisFollowsIds), backupposts: getPostsByUserIds(heAndhisFollowsIds), hiddenstate: false};
        }
        // this.load()
        // this.state = {posts: getPostsByUsername(userName), backupposts: getPostsByUsername(userName)};
    }

    async componentDidMount() {
        const Barticles = await getArticles()
        this.setState({posts: Barticles})
    }

    // async load() {
    //     const Barticles = await getArticles()
    //     this.setState({posts: Barticles})
    // }

    // for search box
    handleSearchByText = searchText => {
        // console.log(searchText);
        let allposts = this.state.backupposts;
        var filtered = allposts.filter(function (value, index, arr){
            return value.body.includes(searchText) || value.title.includes(searchText)
        });
        this.setState({posts: filtered});
    }

    // for add/delete follow
    follow2post_func = follows_ids => {
        // let userIds = follows.map(obj => {return obj.id});
        let userIds = follows_ids;
        userIds.unshift(this.state.userId);
        let shouldPosts = getPostsByUserIds(userIds);
        // console.log(shouldPosts.length);
        // console.log(userIds);
        // console.log("shit");

        this.setState({posts:[], backupposts:[]});
        // this.forceUpdate();
        this.setState({posts: shouldPosts, backupposts: shouldPosts});
    }

    handleHideShowComment(){
        this.setState({hiddenstate: !this.state.hiddenstate});
    }

    handleAddPost(text, img, comments){
        // let newPost = {"userId": posts[0].userId, "id": posts[9].id+1, "title":"", "body":text, time: new Date(), imgs:imgs, comments: comments};
        let oldposts = this.state.posts;
        var payload
        if(img) {
            console.log("exec")
            payload = new FormData();
            payload.append('text', text)
            payload.append('img', img)
            payload.append('comments', [])
            fetch(`${apiUrl}/article`, {
                credentials: "include",
                method: "POST",
                body: payload,
                // headers: {'Content-Type':'application/json'}
            })
                // .then((res) => console.log(res))
                .then((response) => response.json())
                .then((resp) => {
                    if(resp.result === 'success') {
                        var newPost = resp.articles[0]
                        oldposts.unshift(newPost)
                        this.setState({
                            posts: oldposts,
                            backupposts: oldposts
                        })
                        console.log("Successfully Added New Article")
                    }
                    else {
                        // TODO What may cause failed post uploading?
                        console.log("failed in uploding post")
                    }
                })
                .catch((err) => {
                    console.log(err.message)
                })
        }
        else{
            var BODY = {
                text: text,
                img: img,
                comments: []
            }
            console.log(BODY)
            fetch(`${apiUrl}/article`, {
                credentials: 'include',
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(BODY)
            })
                // .then((res) => console.log(res))
                .then((response) => response.json())
                .then((resp) => {
                    if(resp.result === 'success') {
                        var newPost = resp.articles[0]
                        oldposts.unshift(newPost)
                        this.setState({
                            posts: oldposts,
                            backupposts: oldposts
                        })
                        console.log("Successfully Added New Article")
                    }
                    else {
                        // TODO What may cause failed post uploading?
                        console.log("failed in uploding post")
                    }
                })
                .catch((err) => {
                    console.log(err.message)
                })
        }

    }

    render() {
        return (
            <>
                {/*<NewPost />*/}
                <div>
                    <Follows userId={this.state.userId} follow2post={this.follow2post_func} />
                </div>
                <NewPost onClick={this.handleAddPost}/>
                <SearchBox searchByText={this.handleSearchByText}/>
                <div className="posts" id={"posts"}>
                    <table>
                        <thead defaultValue={"Posts"}></thead>
                        <tbody>
                        {/*{posts = this.state.posts}*/}
                        {/*{this.state.posts.map( ({v, ID, author, text, imgs, date, comments}) => {*/}
                        {/*    console.log(v)*/}
                        {/*    console.log(ID)*/}
                        {/*    console.log(author)*/}
                        {/*    console.log(text)*/}
                        {/*    console.log(imgs)*/}
                        {/*    console.log(date)*/}
                        {/*    console.log(comments)*/}
                        {/*} )}*/}
                        {
                            // this.state.posts.map()
                        }
                        {this.state.posts.map( ({v, ID, author, text, img, date, comments}) => (
                            <tr key={uuid()}>
                                <td>{author}</td>
                                <td>{text}</td>
                                <td><img src={img} width={"30%"} height={"30%"} alt={"IMG Not Found"}/></td>
                            </tr>
                        ) )}
                        {/*{this.state.posts.map( ({ userId, id, title, body, time, author, imgs, comments }) => (*/}
                        {/*    <tr>*/}
                        {/*        <th>{time.getDate() + "/"*/}
                        {/*            + (time.getMonth()+1)  + "/"*/}
                        {/*            + time.getFullYear() + " @ "*/}
                        {/*            + time.getHours() + ":"*/}
                        {/*            + time.getMinutes() + ":"*/}
                        {/*            + time.getSeconds()}</th>*/}
                        {/*        <th>{title}</th>*/}
                        {/*        <th>{author}</th>*/}
                        {/*        <th>{body}</th>*/}
                        {/*        <th><img src={imgs[0]} alt={""} height={"60%"} width={"60%"} hidden={!imgs[0]}/></th>*/}
                        {/*        <th hidden={this.state.hiddenstate}>{comments.map((cmt) => <p>{cmt}</p>)}</th>*/}
                        {/*        /!*<th><img src={imgSrc} height={"160%"} width={"60%"}/></th>*!/*/}
                        {/*        <th><button>Comment</button><br /><button>Edit Article</button><br /><button onClick={this.handleHideShowComment}>Show/Hide Comments</button></th>*/}
                        {/*    </tr>*/}
                        {/*) )}*/}
                        </tbody>
                    </table>
                </div>
            </>
        )
    }

}

export class Follows extends React.Component {
    constructor(props) {
        super(props);
        const userId = this.props.userId;

        let hisFollowsIds = [(userId + 1) % 10, (userId + 2) % 10, (userId + 3) % 10];
        var hisFollows = users.filter(function(value, idx, arr) {
            return hisFollowsIds.includes(value.id);
        })
        if (userId === 100) {
            hisFollows = [];
        }
        this.state = { hisFollows: hisFollows, addFollowText: "", errorText: "" };
        this.handleUnfollow = this.handleUnfollow.bind(this);
        this.handleAddFollow = this.handleAddFollow.bind(this);
    }

    handleUnfollow(e) {
        var id = e.target.id;
        var hisFollows = this.state.hisFollows;
        var newFollows = hisFollows.filter(function(value, idx, arr) {
            return value.id !== id;
        })
        this.setState({hisFollows: newFollows})
        let newFollows_ids = newFollows.map(obj => {return obj.id});
        if (this.props.follow2post) {
            this.props.follow2post(newFollows_ids);
            // console.log(newFollows_ids.length);
        }
    }

    handleAddFollow(e) {
        var addText = this.state.addFollowText;
        var addFollow = users.filter(function(value, idx, arr) {
            return value.name === addText;
        })[0]
        if (addFollow) {
            let oldFollows = this.state.hisFollows;
            console.log(oldFollows[0]);
            oldFollows.unshift(addFollow);
            console.log(addFollow);
            let allFollows = oldFollows;
            let allFollows_ids = allFollows.map(obj => {return obj.id});
            this.setState({hisFollows: allFollows, errorText: ""})
            if (this.props.follow2post) {
                this.props.follow2post(allFollows_ids);
            }
        }
        else {
            this.setState({errorText: "No User Found!"})
        }

    }

    render() {
        // console.log(this.state.hisFollows);
        return (
            <table>
                <thead defaultValue={"Users You are Following:"}></thead>
                <tbody>
                <tr><td><h2>Followed Users</h2></td></tr>
                    <tr><td><span className={"warning"}>{this.state.errorText}</span></td></tr>
                    {this.state.hisFollows.map( ({id, name, username, email, address, phone, website, company}) => (

                        <tr>
                            <td>
                                <div>
                                    <img src={imgSrc} alt={"imgSrc didn't give me a pic!"} width={"10%"} height={"10%"}></img><br />
                                    <span>{name}</span><br />
                                    <span>{company.catchPhrase}</span>
                                    <button id={id} name={"unfollow"+name} onClick={this.handleUnfollow}>Unfollow</button>
                                </div>
                            </td>
                        </tr>
                    ) )}
                    <tr>
                        <td>
                        <input name={"followTypein"} type={"text"} onChange={e => {this.setState({addFollowText: e.target.value})}}></input>
                        <button name={"addFollowButton"} onClick={this.handleAddFollow}>Add Follow</button><br></br>
                        <span>Type in user's name to follow him, and click the button, try "Leanne Graham",<br></br> only registered users can be found</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        )
    }

}


export class NewPost extends React.Component{
    constructor(props) {
        super(props);
        this.handleClear = this.handleClear.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.file = ""
        // this.handleSubmit =
        this.state = {inputText: "You can add new articles here!!", img: "", comments: []}
    }

    handleImageChange(e) {
        e.preventDefault()
        let reader = new FileReader()
        reader.onloadend = () => {
            this.preview = reader.result
            this.forceUpdate()
        }
        console.log(e.target.files.length)
        if (e.target.files.length !== 0) {
            this.file = e.target.files[0]
            console.log(this.file)
            reader.readAsDataURL(this.file)
        }
    }

    handleClear(event) {
        this.refs.inputText.value = "";
    }

    handleSubmit(e){
        if (this.props.onClick){
            this.props.onClick(this.state.inputText, this.file, this.state.comments);
        }
        // this.props.onSubmit(this.state);
    }

    render() {
        return (
        <div>
            <h2>Write a New Post</h2><br></br>
            <textarea ref={"inputText"}  defaultValue={this.state.inputText} onChange={evt => this.setState({inputText: evt.target.value})}/><br />
            <span>Choose a photo from your device</span><br />
            {/*<input type={"file"} accept="image/*" onChange={evt => this.setState({imgs:[evt.target.value]})}></input>*/}
            <input type={"file"} accept="image/*" onChange={(e) => this.handleImageChange(e)}></input>
            <button onClick={this.handleClear}>Clear</button>
            <button onClick={this.handleSubmit}>Post</button>
        </div>
        )
    }
}

export class SearchBox extends React.Component{
    constructor(props) {
        super(props);
        this.state = {searchText: ""};
        this.handleSearchText = this.handleSearchText.bind(this);
    }

    handleSearchText(e) {
        if(this.props.searchByText) {
            this.props.searchByText(this.state.searchText);
        }
    }

    render() {
        return (
            <div>
                <h2>Search posts by text or author</h2>
                <textarea name="searchTextArea" ref={"searchText"} defaultValue={this.state.searchText} onChange={evt => this.setState({searchText: evt.target.value})}/><br/>
                <button onClick={this.handleSearchText}>Search by text or author</button>
                {/*<button>Search by author</button>*/}
            </div>
        )
    }
}


function getPostsByUserIds(userIds) {
    var feeds = [];
    for (let i = 0; i < userIds.length; i++) {
        let newFeeds = posts.filter((post) => post.userId === userIds[i]);
        feeds.push(...newFeeds);
    }
    for (let i=0; i<feeds.length; i++) {
        feeds[i].time = new Date(2015-i, 2);
        feeds[i].author = users.filter((user) => user.id === feeds[i].userId)[0].username;
        feeds[i].imgs = [imgSrc];
        feeds[i].comments = ['Comment 111', 'Comment 222', 'Comment 333'];
    }
    return feeds
}
